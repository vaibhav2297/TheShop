---
description: Write and run unit/component tests for a specific feature. Invokes shop-test-writer to generate test cases from the spec, then shop-test-runner to execute them, and produces a combined verdict. E2E journeys are out of scope — see /theshop.e2e.
argument-hint: <feature-name>
---

# /theshop.test

**Feature requested:** `$ARGUMENTS`

You are the orchestrator for a two-step test workflow on **The Shop** project. You do not write tests, run tests, or read specs yourself — you delegate to two specialist sub-agents and then combine their reports. You never edit code.

## Input validation

If `$ARGUMENTS` is empty (the user invoked `/theshop.test` with no feature name), stop and ask:

> "Please provide a feature name. Usage: `/theshop.test <feature-name>` — for example, `/theshop.test add-to-cart`. The feature name must match an existing spec at `.specs/{feature_name}/spec.md`."

Wait for the user's reply. Do nothing else.

If a feature name is present, proceed.

---

## Step 1 — Invoke `shop-test-writer`

Call the `shop-test-writer` sub-agent via the Task tool, with `subagent_type: shop-test-writer`. The prompt to that agent should be:

> "Write test cases for the feature `$ARGUMENTS`. Read the spec at `.specs/$ARGUMENTS/spec.md` (your behavioral oracle) and the plan at `.specs/$ARGUMENTS/plan.md` (your structural map — it reveals the Infrastructure seams the spec hides) and produce runnable test files in the appropriate `tests/TheShop.*.Tests/` projects. Do not write an E2E journey — `/theshop.e2e` owns E2E entirely. Follow your standard protocol and end with the structured summary."

Wait for the sub-agent to fully complete its turn. Do not begin Step 2 in parallel, and do not pre-empt the sub-agent's output.

When the sub-agent returns, inspect its closing summary:

- **If it created test files** (the "Files created/modified" list is non-empty), continue to Step 1.5.
- **If it halted without writing tests** — for example, the spec was missing, ambiguous, or contradicted itself, or the agent reported unresolved open questions — **stop immediately**. Do not invoke Step 2. Skip to the "Step 1 halted" output template below.

---

## Step 1.5 — Manifest + compile gates (deterministic, between writer and runner)

Before the expensive runner pass, verify the writer's handoff contract mechanically. Two gates, in order: the manifest gate first (cheap artifact check), then the compile gate (builds the test projects). Each may trigger at most **one** writer re-invocation.

### Gate A — manifest

```bash
pwsh -NoProfile -ExecutionPolicy Bypass -File .claude/scripts/check-sdd-gates.ps1 manifest -Feature $ARGUMENTS
```

The script checks what the runner would otherwise discover only after a full diagnostic pass: the manifest parses, `totalTests` equals the sum of the per-class counts, every listed file exists on disk and carries the `[Trait("Feature", "$ARGUMENTS")]` stamp, every AC id from the spec appears in `acceptanceCriteria` (and none are invented), and every mapped test name belongs to a listed class.

- **Exit 0** → proceed to Gate B.
- **Exit 1** → re-invoke `shop-test-writer` **once**, quoting the gate's violation list verbatim with the instruction: "Your manifest/test handoff failed the deterministic gate. Fix exactly these violations and re-emit the structured summary." Then re-run the gate. If it fails a second time, **stop** — report with Template B, quoting the gate output as the halt reason. Do not hand a broken manifest to the runner; its reconciliation would fail anyway, just more expensively.

### Gate B — compile

```bash
pwsh -NoProfile -ExecutionPolicy Bypass -File .claude/scripts/check-sdd-gates.ps1 compile -Feature $ARGUMENTS
```

The script `dotnet build`s every test project the manifest lists (transitively compiling the production layers they reference) and emits each compiler error tagged by the failing file's location: `[tests]` for errors in test files, `[src]` for errors in production code. This catches at write time what the runner's own build gate would otherwise discover only after a fresh invocation — and catches it while the one agent allowed to edit `tests/` can still be re-invoked. It builds; it never executes tests.

Route by the tags in the gate's output:

- **Exit 0** → refresh the knowledge graph so the new test files land in it — `graphify update .` (AST-only; writes only under `graphify-out/`; skip silently if `graphify` or `graphify-out/graph.json` is unavailable) — then proceed to Step 2.
- **Exit 1, all errors tagged `[tests]`** → re-invoke `shop-test-writer` **once**, quoting the error list verbatim with the instruction: "Your test files do not compile. Fix exactly these compiler errors. You may glance at production code to align type/method names and signatures so the tests compile — never to change what a test expects. If an error is caused by a production type or member that does not exist yet (the feature is unimplemented), do not weaken, comment out, or delete the test — leave it and report the missing symbol in your summary." Then re-run Gate B.
  - If the writer reports the errors come from **missing production symbols** (the feature hasn't been implemented yet), **stop** and report with Template C, noting explicitly that the tests are written and awaiting implementation — an expected pre-implementation state, not a writer defect. Point the user at `/theshop.implement $ARGUMENTS`.
  - If Gate B fails a second time on `[tests]` errors that were the writer's to fix, **stop** — report with Template C, quoting the gate output.
- **Exit 1, any error tagged `[src]`** → do **not** re-invoke the writer — it is forbidden from touching production code and cannot fix this. **Stop** and report with Template C: production code does not compile, so the feature's tests are written but blocked. Name the broken project/file(s) from the gate output.


---

## Step 2 — Invoke `shop-test-runner`

Only reachable if Step 1 produced test files.

Call the `shop-test-runner` sub-agent via the Task tool, with `subagent_type: shop-test-runner`. The prompt to that agent should be:

> "Run the test cases for the feature `$ARGUMENTS`. Follow your standard protocol: read the manifest at `.specs/$ARGUMENTS/test-manifest.json`, run targeted by feature trait (`--filter \"Feature=$ARGUMENTS\"`), reconcile the discovered test count against the manifest's `totalTests`, evaluate each acceptance criterion against the manifest's `acceptanceCriteria` mapping, analyze across the five layers, and deliver the six-section structured report (including the Acceptance criteria table) with a final verdict. Treat any reconciliation mismatch, any failing acceptance criterion, or any uncovered acceptance criterion as 🔴 NOT READY."

Wait for it to fully complete.

---

## Handoff rules (enforce strictly)

1. **Do not start Step 2 until Step 1 is fully complete.** If the writer is still working, wait. No parallel invocation.
2. **Do not fix any code regardless of what the test results show.** Your job ends at delivering the combined summary — plus updating the feature's tracking artifact `.specs/$ARGUMENTS/status.md` and persisting the combined report to `.specs/$ARGUMENTS/test-report.md` (see below), neither of which is code. The user is the one who acts on it. If they ask you to fix something inside this command run, tell them the slash command is orchestration-only and they can request fixes in a follow-up message.
3. **Do not run anything outside `tests/`.** The runner agent handles all test execution; you never invoke `dotnet test` yourself. The commands you do run are the Step 1.5 gates (`check-sdd-gates.ps1 manifest` and `compile`) — the first is a read-only artifact check, the second builds the manifest's test projects but never executes a test — plus the post-Gate-B `graphify update .`, which writes only under `graphify-out/` (a knowledge-graph refresh, not code), plus a read-only `git rev-parse --short HEAD` to stamp the persisted report.
4. **If `shop-test-writer` could not write the test files, stop and report the reason.** Do not proceed to Step 2 under any circumstance — not even "to see what's already there".
5. **This command never writes or runs E2E journeys.** `/theshop.e2e` owns E2E entirely — writing and running the journey in its own single context. If the writer's summary mentions an E2E journey, that is stale behavior from before the split; do not include it in any count, filter, or report section.

---

## Update the status tracker

After you settle the verdict (Template A only), update `.specs/$ARGUMENTS/status.md`: set the **Test** row to State `Passing` when the verdict is ✅ Ready, or `Failing` when it is ❌ Needs fixes; Gate `✅ manifest + reconciliation pass` or `🔴 {which gate failed}`; Evidence one line of the run's numbers **plus a link to the persisted report** (e.g. `194/194 reconciled · 12/12 ACs ✅ — see [test-report.md](./test-report.md)` or `reconciliation mismatch 180/194 — see [test-report.md](./test-report.md)`); today's date. Refresh **Last updated**; point **Next step** at `/theshop.e2e $ARGUMENTS` (Passing) or back at the fix the runner named (Failing). On Template B (writer halted) leave the tracker untouched; on Template C (build failed) set **Test** to `Failing` with Gate `🔴 build gate` and the failing project as Evidence (append `— see [test-report.md](./test-report.md)`). Create `status.md` from the `theshop.spec` template first if it's missing.

## Persist the test report

On **Template A** and **Template C** runs — any run where the pipeline actually executed (tests ran, or the build failed trying to compile them) — persist the combined report to `.specs/$ARGUMENTS/test-report.md`. The manifest is a stable spec of *which* tests should exist; this file is the durable record of *what happened* on the run — the per-failure breakdown, reconciliation detail, and AC pass/fail that otherwise vanish once the session scrolls away.

Rules:

- **One file, overwrite.** Write (never append) the full combined summary to `.specs/$ARGUMENTS/test-report.md` — the *exact same* Template A or Template C content you emit as Final output, stamp included. Each run replaces the last; git carries the history. Never accumulate dated report files and never create a `test/` subfolder.
- **The stamp is part of the template.** Templates A and C already carry the two stamp lines under the heading. Fill `{date}` with today's date, `{short-sha}` from `git rev-parse --short HEAD` (write `(unknown)` if that command fails — e.g. not a git checkout), and `{verdict}` with the settled verdict. The persisted file and your Final output must be identical.
- **Template B (writer halted): do not write the report.** Nothing was produced, so there is nothing to persist — this mirrors leaving `status.md` untouched. The in-session halt reason is enough.
- Write the file as part of the same step that updates `status.md`, before emitting Final output. This is the one file you write outside `status.md`; it is a record, not code, so it does not violate the orchestration-only handoff rules.

## Final output

After both agents complete (or after Step 1 halts, or a Step 1.5 gate stops the pipeline), produce a combined summary in **exactly** one of the three templates below — Template A when the run completed, Template B when the writer halted (or Gate A failed twice), Template C when a build failed — whether at the Step 1.5 compile gate or the runner's own build gate — so no tests ran. No extra prose before or after.

### Template A — Both steps ran

```markdown
# Test report — {feature_name}

_Run: {date} · commit `{short-sha}` · verdict {✅ Ready / ❌ Needs fixes}_
_Snapshot of one run — regenerate with `/theshop.test {feature_name}`._

## Tests written (shop-test-writer)

{One-line list of files created, taken from the writer's summary.}

- `tests/TheShop.{Layer}.Tests/{path}/{File}.cs` — {N} tests
- ...

**Coverage by category:** Happy path: {✅/⚠️} · Validation: {✅/⚠️} · Edge cases: {✅/⚠️} · Auth guard: {✅/⚠️/N-A}

## Tests run (shop-test-runner)

| Metric | Value |
|---|---|
| Expected (manifest) | {N} |
| Discovered/run | {N} |
| Reconciliation | {✅ matched / 🔴 mismatch — {discovered} vs {expected}} |
| Passed | {N} |
| Failed | {N} |
| Skipped | {N} |
| Pass rate | {%} |
| Runner status | {🟢 Green / 🟡 Yellow / 🔴 Red} |

{If reconciliation did not match, add a single line naming the cause: 🔴 Reconciliation mismatch — {missing classes not run, or extra classes that ran}. This alone forces the "Needs fixes" verdict.}

{If the runner reported failures, list each one in a single line: ❌ `{TestFullName}` — {one-line cause}. If none, write "No failures."}

{If the runner flagged warnings, list each in a single line: ⚠️ {one-line description}. If none, write "No warnings flagged."}

## Acceptance criteria

{One row per AC from the runner's Acceptance criteria section, referenced by id only — the spec owns the wording.}

| AC | Status |
|---|---|
| AC-1 | {✅ Passed / ❌ Failed / ⚠️ Not Covered} |
| AC-2 | {✅ Passed / ❌ Failed / ⚠️ Not Covered} |

**AC status:** {N} passed · {N} failed · {N} not covered

{If the runner could not verify ACs — no `acceptanceCriteria` in the manifest and no `// AC → Test mapping` footer — replace the table with: "⚠️ AC verification not performed — no AC oracle available." and treat it as a blocker for the "Ready" verdict.}

## Verdict

{One of:}
- **✅ Ready for code review — all tests pass and all acceptance criteria pass**  *(use only when runner status is 🟢 Green: 100% pass, no skipped tests, no warnings, and every AC ✅ Passed)*
- **❌ Needs fixes**  *(use for 🟡 Yellow or 🔴 Red — including clean failures, skipped tests, warning flags, any ❌ Failed AC, or any ⚠️ Not Covered AC)*

{One sentence justifying the verdict. "Ready" requires BOTH every test passing AND every acceptance criterion passing. For "Needs fixes", point at the specific blocker(s) — name failing/uncovered AC ids where relevant.}

---

*Full per-failure breakdown and recommendations are in the shop-test-runner output above. The user should refer to that for fix guidance.*
```

### Template B — Step 1 halted

```markdown
# Test report — {feature_name}

## Tests written (shop-test-writer)

**Status:** ⛔ Halted — no test files were produced.

**Reason given by shop-test-writer:**

> {Verbatim quote of the writer's stop reason — e.g., "No spec found at .specs/{feature_name}/spec.md", or "Spec section 'Acceptance Criteria' is empty", or "Open questions remain — agent asked the user for clarification before writing tests".}

## Tests run (shop-test-runner)

**Skipped** — per the handoff rules, the runner is not invoked when no tests exist.

## Verdict

**⛔ Blocked — tests could not be written**

{One sentence describing what the user needs to do next — typically "Resolve the issue reported above (e.g., create or fix the spec at `.specs/{feature_name}/spec.md`) and re-run `/theshop.test {feature_name}`."}
```

### Template C — Build gate failed (Step 1.5 compile gate or runner)

Use this when Step 1 produced tests but a **build failure** stopped the pipeline. Two sources:

- **The Step 1.5 compile gate** tripped and could not be cleared — `[src]` errors (production code broken), missing production symbols (feature not yet implemented), or `[tests]` errors that survived the single writer retry. The runner was never invoked; say so in the "Tests run" section and use the gate's tagged error list as the build errors.
- **`shop-test-runner`'s own Step 2 build gate** tripped — recognizable by the runner returning the trimmed build-failure report: a `Build: 🔴 Failed` summary row and a `🔴 NOT READY — build failed` verdict, with no pass/fail metrics.

Either way, the solution did not compile and no tests ran. Do **not** force this into Template A — there are no test counts to show.

```markdown
# Test report — {feature_name}

_Run: {date} · commit `{short-sha}` · verdict ❌ Needs fixes_
_Snapshot of one run — regenerate with `/theshop.test {feature_name}`._

## Tests written (shop-test-writer)

{One-line list of files created, taken from the writer's summary.}

- `tests/TheShop.{Layer}.Tests/{path}/{File}.cs` — {N} tests
- ...

## Tests run (shop-test-runner)

**Status:** 🔴 Build failed — the solution did not compile, so no tests ran. {If the Step 1.5 compile gate stopped the pipeline, add: "The runner was not invoked — the compile gate caught this first."}

**Build errors (from the compile gate or the runner):**
- `{project}` — `{file}:{line}` — `error CSxxxx`: {message}
- ...

{If the break is in a project/file NOT part of this feature's test set (the gate's `[src]` tag, or the runner's flag), surface that here — the feature's own tests are blocked by an unrelated compile error.}

{If the writer reported the errors come from production symbols that don't exist yet, say instead: "The tests are written and compile-blocked only because the feature is not implemented yet — run `/theshop.implement {feature_name}` first, then re-run `/theshop.test {feature_name}`."}

## Acceptance criteria

Not verified — nothing compiled, so no acceptance criterion could be exercised. All ACs remain ⚠️ unverified until the build is green.

## Verdict

**❌ Needs fixes — build failed**

The code does not compile, so the tests for `{feature_name}` never ran and no acceptance criterion is verified. Fix the build error(s) listed above and re-run `/theshop.test {feature_name}`. This is a "tests did not execute" state, not a test failure.
```

---

## Verdict rules (be strict)

The two-outcome verdict is intentional and the boundary is sharp:

- **"Ready for code review"** is reserved for a fully clean run — the discovered test count reconciled exactly against the manifest (every test that should have run did run, nothing extra), every one passed, **every acceptance criterion is ✅ Passed**, nothing was skipped, no sneaky-issue warnings were flagged.
- **"Needs fixes"** covers everything else: any reconciliation mismatch (fewer or more tests ran than the manifest promised), any failure, any build error, any skipped test, any ❌ Failed acceptance criterion, any ⚠️ Not Covered acceptance criterion, any warning the runner surfaced (e.g., `Thread.Sleep` in tests, vacuous tests, `[Fact(Skip)]`). A skipped test is not a passed test, a mismatch means coverage is unverified, an uncovered AC means the definition of done is unverified, and a warning means the green light is misleading.

A reconciliation mismatch is a hard blocker on its own — even if every test that ran passed, you do **not** call it "Ready", because some of the feature's tests may never have executed. The same is true of the acceptance criteria: passing tests are necessary but not sufficient — if any AC is ❌ Failed or ⚠️ Not Covered, it is "Needs fixes", because the feature's definition of done has not been met.

If you're tempted to call something "Ready" with a footnote — don't. That's what "Needs fixes" is for.

A **build failure** — whether caught by the Step 1.5 compile gate or reported by the runner — is a special case of "Needs fixes": render it with **Template C**, not Template A, because the solution never compiled and there are no pass/fail metrics to report — the tests did not execute. It is still "Needs fixes," just with a build-error breakdown in place of the metrics table. The one nuance: when the only blocker is missing production symbols (feature not yet implemented), Template C should route the user to `/theshop.implement`, not to a test fix.
